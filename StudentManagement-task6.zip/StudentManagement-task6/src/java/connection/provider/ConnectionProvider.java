/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package connection.provider;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import property.file.PropertiesData;
/**
 *
 * @author Munish kumar
 */
public class ConnectionProvider {
    //singleton
    static ConnectionProvider connectionProvider = null;
    PropertiesData PropertiesData = new PropertiesData();
    
    private ConnectionProvider(){}
    
    public static ConnectionProvider getInstance(){
        if(connectionProvider == null){
            connectionProvider = new ConnectionProvider();
        }
        return connectionProvider;
    }
        
    public Connection getConnection() throws FileNotFoundException, IOException{
        try{
            Class.forName(PropertiesData.getPropertiseData("driver"));
            Connection con = DriverManager.getConnection(PropertiesData.getPropertiseData("url"),PropertiesData.getPropertiseData("username"),PropertiesData.getPropertiseData("password"));
            return con;
        }catch(Exception e){
            return null;
        }
    }
}
