/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.student.manager;

import connection.provider.ConnectionProvider;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import property.file.PropertiesData;
import student.management.Admin;

/**
 *
 * @author Munish kumar
 */
public class AdminDao implements AdminDaoInterface {
    private static final ConnectionProvider CONNECTION_PROVIDER = ConnectionProvider.getInstance();
    PropertiesData PropertiesData = new PropertiesData();

    @Override
    public String getAdminNameByAdminId(String adminId) {
        String adminName = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_ADMINNAME_BY_ADMINID"));
            preparedStatement.setString(1, adminId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            adminName = rs.getString(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(AdminDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return adminName;
    }

    @Override
    public String getAdminPasswordByAdminId(String adminId) {
        String adminPassword = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_ADMINPASSWORD_BY_ADMINID"));
            preparedStatement.setString(1, adminId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            adminPassword = rs.getString(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(AdminDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return adminPassword;
    }

    @Override
    public boolean setAdminData(Admin admin) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("INSERT_ADMIN_SQL"));
            preparedStatement.setString(1, admin.getId());
            preparedStatement.setString(2, admin.getName());
            preparedStatement.setString(3, admin.getPassword());
            int n = preparedStatement.executeUpdate();
            if(n == 0){
                flag = false;
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
}
