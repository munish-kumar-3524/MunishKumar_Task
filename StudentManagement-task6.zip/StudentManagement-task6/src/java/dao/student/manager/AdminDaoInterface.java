/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao.student.manager;

import student.management.Admin;

/**
 *
 * @author Munish kumar
 */
public interface AdminDaoInterface {
    public boolean setAdminData(Admin admin);
    public String getAdminNameByAdminId(String adminId);
    public String getAdminPasswordByAdminId(String adminId);
}
