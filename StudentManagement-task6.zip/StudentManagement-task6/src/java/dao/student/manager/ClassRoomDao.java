/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.student.manager;

import connection.provider.ConnectionProvider;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import student.management.ClassRoom;
import property.file.PropertiesData;

/**
 *
 * @author Munish kumar
 */
public class ClassRoomDao implements ClassRoomDaoInterface {
    private static final ConnectionProvider CONNECTION_PROVIDER = ConnectionProvider.getInstance();
    PropertiesData PropertiesData = new PropertiesData();
    
//    private Set<Integer> getStaffHandlingIdByClassRoomId(String classRoomId) throws IOException{
//        Set<Integer> setOfStaffHandlingId = new HashSet<>();
//        try{
//            Connection connection = CONNECTION_PROVIDER.getConnection();
//            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STAFFHANDLINGID_BY_CLASSROOMID_SQL"));
//            preparedStatement.setString(1, classRoomId);
//            ResultSet rs = preparedStatement.executeQuery();
//            while(rs.next()){
//                setOfStaffHandlingId.add(rs.getInt("staff_handling_id"));
//            }
//        }catch(SQLException e){
//            System.out.println(e);
//        }
//        return setOfStaffHandlingId;
//    }

    @Override
    public boolean insertClassRoom(ClassRoom classRoom) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("INSERT_CLASSROOM_SQL"));
            preparedStatement.setString(1, classRoom.getId());
            preparedStatement.setString(2, classRoom.getName());
            int n = preparedStatement.executeUpdate();
            if(n == 0){
                flag = false;
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }

    @Override
    public boolean insertClassRoomStaffWithSubject(String classRoomId, int StaffHandlingId) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("INSERT_CLASSROOM_STAFF_WITH_SUBJECT_SQL"));
            preparedStatement.setString(1, classRoomId);
            preparedStatement.setInt(2, StaffHandlingId);
            int n = preparedStatement.executeUpdate();
            if(n == 0){
                flag = false;
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }

    @Override
    public String getClassRoomIdByClassRoomName(String ClassRoomName) {
        String classRoomId = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_CLASSROOMID_BY_CLASSROOMNAME_SQL"));
            preparedStatement.setString(1, ClassRoomName);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            classRoomId = rs.getString("classroom_name");
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return classRoomId;
    }

    @Override
    public String getClassRoomNameByClassRoomId(String ClassRoomId) {
        String classRoomName = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_CLASSROOMNAME_BY_CLASSROOMID_SQL"));
            preparedStatement.setString(1, ClassRoomId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            classRoomName = rs.getString("classroom_name");
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return classRoomName;
    }

    @Override
    public int removeRowFromClassroomStaffWithSubject(String ClassRoom_id, int Staff_handling_id) {
        int numberOfChangesInTheTable = 0;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("DELETE_SINGLEROW_FROM_CLASSROOM_STAFF_WITH_SUBJECT"));
            preparedStatement.setString(1, ClassRoom_id);
            preparedStatement.setInt(2, Staff_handling_id);
            numberOfChangesInTheTable = preparedStatement.executeUpdate();
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return numberOfChangesInTheTable;
    }

    @Override
    public Set<String> getAllClassRoomId() {
         Set<String> setOfClassRoomId = new HashSet<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(PropertiesData.getPropertiseData("SELECT_CLASSROOMID_SQL"));
            while(rs.next()){
                String id = rs.getString("classroom_id");
                setOfClassRoomId.add(id);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return setOfClassRoomId;
    }

    @Override
    public boolean insertClassRoomAndStudent(String classRoomId, String studentId) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("INSERT_CLASSROOM_AND_STUDENT_SQL"));
            preparedStatement.setString(1, classRoomId);
            preparedStatement.setString(2, studentId);
            int n = preparedStatement.executeUpdate();
            if(n == 0){
                flag = false;
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }

    @Override
    public Set<String> getStudentIdsByClassRoomId(String ClassRoom_Name) {
        Set<String> setOfStudentId = new HashSet<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STUDENTIDS_BY_CLASSROOMID"));
            preparedStatement.setString(1, ClassRoom_Name);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                String id = rs.getString("student_id");
                setOfStudentId.add(id);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return setOfStudentId;
    }

    @Override
    public int countOfStudentInTheClassroom(String classRoomId) {
        int numberOfStudents = 0;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_COUNT_OF_STUDENT_IN_THE_CLASS"));
            preparedStatement.setString(1, classRoomId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                numberOfStudents = rs.getInt(1);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return numberOfStudents;
    }

    @Override
    public String getClassRoomIdByStudentId(String studentId) {
        String classRoomId = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_CLASSROOMID_BY_STUDENTID"));
            preparedStatement.setString(1, studentId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            classRoomId = rs.getString("classroom_id");
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return classRoomId;
    }
}
