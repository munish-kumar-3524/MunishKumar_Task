/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao.student.manager;

import java.util.Set;
import student.management.ClassRoom;

/**
 *
 * @author Munish kumar
 */
public interface ClassRoomDaoInterface {
    
    public boolean insertClassRoom(ClassRoom classRoom);
    public boolean insertClassRoomStaffWithSubject(String classRoomId, int StaffHandlingId) ;
    public String getClassRoomIdByClassRoomName(String ClassRoom_Name) ;
    public String getClassRoomNameByClassRoomId(String ClassRoomId) ;
    public int removeRowFromClassroomStaffWithSubject(String ClassRoom_id, int Staff_handling_id);
    public Set<String> getAllClassRoomId() ;
    public boolean insertClassRoomAndStudent(String classRoomId, String studentId);
    public Set<String> getStudentIdsByClassRoomId(String ClassRoom_Name);
    public int countOfStudentInTheClassroom(String classRoomId);
    public String getClassRoomIdByStudentId(String studentId);
    
}
