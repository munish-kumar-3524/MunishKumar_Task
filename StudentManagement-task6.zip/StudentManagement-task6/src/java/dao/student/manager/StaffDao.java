/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.student.manager;

import connection.provider.ConnectionProvider;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import student.management.Staff;
import student.management.Subject;
import property.file.PropertiesData;

/**
 *
 * @author Munish kumar
 */
public class StaffDao implements StaffDaoInterface {
    private static final ConnectionProvider CONNECTION_PROVIDER = ConnectionProvider.getInstance();
    PropertiesData PropertiesData = new PropertiesData();
    SubjectDaoInterface subjectDao = new SubjectDao();
    //StaffDaoInterface staffDao = new StaffDao();

    @Override
    public boolean insertStaff(Staff staff) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("INSERT_STAFF_SQL"));
            preparedStatement.setString(1, staff.getId());
            preparedStatement.setString(2, staff.getName());
            preparedStatement.setString(3, staff.getPassword());
            int n = preparedStatement.executeUpdate();
            if(n == 0){
                flag = false;
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }

    @Override
    public boolean insertStaffHandlingSubject(Staff staff) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            for(String subject : staff.getHandlingSubjects()){
                String subjectId = subjectDao.getSubjectIdBySubjectName(subject);
                PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("INSERT_STAFF_HANDLING_SUBJECT_SQL"));
                preparedStatement.setString(1, staff.getId());
                preparedStatement.setString(2, subjectId);
                int n = preparedStatement.executeUpdate();
                if(n == 0){
                    flag = false;
                }
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }

    @Override
    public int getStaffHandlinfIdByStaffIdAndSubjectId(String staffId, String subjectId) {
        int staffHandlingId = 0;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STAFF_HANDLING_ID_BY_SUBJECTID_AND_STAFFID"));
            preparedStatement.setString(1, staffId);
            preparedStatement.setString(2, subjectId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return 0;
            }
            staffHandlingId = rs.getInt(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return staffHandlingId;
    }

    @Override
    public String getStaffIdByStaffHandlingId(int staffHandlingId) {
        String staffId = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STAFFID_BY_STAFFHANDLINGID"));
            preparedStatement.setInt(1, staffHandlingId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            staffId = rs.getString(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return staffId;
    }

    @Override
    public String getStaffNameByStaffId(String staffId) {
        String staffName= null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STAFFNAME_BY_STAFFID_SQL"));
            preparedStatement.setString(1, staffId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            staffName = rs.getString(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return staffName;
    }

    @Override
    public String getStaffPasswordByStaffId(String staffId) {
        String staffName= null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STAFFPASSWORD_BY_STAFFID_SQL"));
            preparedStatement.setString(1, staffId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            staffName = rs.getString(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return staffName;
    }

    @Override
    public String getsubjectIdByStaffHandlingId(int staffHandlingId) {
        String subjectId = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_SUBJECTID_BY_STAFFHANDLINGID"));
            preparedStatement.setInt(1, staffHandlingId);
            ResultSet rs = preparedStatement.executeQuery();
            rs.next();
            subjectId = rs.getString(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return subjectId;
    }

    @Override
    public String getStaffIdByStaffName(String staff_Name) {
        String staffId = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STAFFID_BY_STAFFNAME_SQL"));
            preparedStatement.setString(1, staff_Name);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            staffId = rs.getString("staff_name");
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return staffId;
    }

    @Override
    public Set<String> getStaffHandlingSubjectId(String staff_id) {
        Set<String> setOfSubject = new HashSet<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_SUBJECTID_BY_STAFFID"));
            preparedStatement.setString(1, staff_id);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                String subjectId = rs.getString("subject_id");
                setOfSubject.add(subjectId);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return setOfSubject;
    }

    @Override
    public Set<Subject> getStaffHandlingSubject(String staffId) {
        Set<Subject> setOfSubject = new HashSet<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_SUBJECTID_BY_STAFFID"));
            preparedStatement.setString(1, staffId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                String subjectId = rs.getString("subject_id");
                SubjectDao subjectDao = new SubjectDao();
                Subject subject = subjectDao.getSubjectBySubjectId(subjectId);
                setOfSubject.add(subject);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return setOfSubject;
    }

    @Override
    public Set<String> getAllStaffIds() {
        Set<String> setOfStaff = new HashSet<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(PropertiesData.getPropertiseData("SELECT_SUBJECT"));
            while(rs.next()){
                String id = rs.getString("staff_id");
                setOfStaff.add(id);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return setOfStaff;
    }

    @Override
    public Set<Staff> getAllStaff() {
        Set<Staff> setOfStaff = new HashSet<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(PropertiesData.getPropertiseData("SELECT_SUBJECT"));
            while(rs.next()){
                String name = rs.getString("staff_name");
                String id = rs.getString("staff_id");
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return setOfStaff;
    }

//    @Override
//    public Staff getStaffById(String staffId) {
//        Staff staff = null;
//        try{
//            Connection connection = CONNECTION_PROVIDER.getConnection();
//            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STAFFNAME_BY_STAFFID_SQL"));
//            preparedStatement.setString(1, staffId);
//            ResultSet rs = preparedStatement.executeQuery();
//            boolean check = rs.next();
//            if(!check){
//                return null;
//            }
//            String staffName = rs.getString(1);
//            Staff tempStaff = new Staff(staffName, staffId);
//            Set<String> setOfSubjectId = staffDao.getStaffHandlingSubjectId(staffId);
//            Set<String> setOfSubjectName = new HashSet<>();
//            for(String subjectId : setOfSubjectId){
//                String subjectName = subjectDao.getSubjectNameBySubjectId(subjectId);
//                setOfSubjectName.add(subjectName);
//            }
//            tempStaff.setHandlingSubjects(setOfSubjectName);
//            staff = tempStaff;
//        }catch(SQLException e){
//            System.out.println(e);
//        } catch (IOException ex) {
//            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return staff;
//    }
    
    @Override
    public int getStaffHandlingOfASpecificClass(String subjectId, String classRoomId) {
        int staffHandlingId = -1;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STAFF_HANDLING_ID_OF_SPECIFIC_CLASS"));
            preparedStatement.setString(1, subjectId);
            preparedStatement.setString(2, classRoomId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                staffHandlingId = rs.getInt(1);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return staffHandlingId;
    }

    @Override
    public int getTotalNumberOfClassAllocatedToASimgleStaff(String staffId) {
        int count = 0;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_COUNT_OF_CLASS_ALLOTED_TO_SINGlE_STAFF"));
            preparedStatement.setString(1, staffId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                count = rs.getInt(1);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
    }
}


