/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao.student.manager;

import java.util.Set;
import student.management.Staff;
import student.management.Subject;

/**
 *
 * @author Munish kumar
 */
public interface StaffDaoInterface {
    
    public boolean insertStaff(Staff staff);
    public boolean insertStaffHandlingSubject(Staff staff);
    public int getStaffHandlinfIdByStaffIdAndSubjectId(String staffId, String subjectId);
    public String getStaffIdByStaffHandlingId(int staffHandlingId);
    public String getStaffNameByStaffId(String staffId);
    public String getStaffPasswordByStaffId(String staffId);
    public String getsubjectIdByStaffHandlingId(int staffHandlingId);
    public String getStaffIdByStaffName(String staff_Name);
    public Set<String> getStaffHandlingSubjectId(String staff_id);
    public Set<Subject> getStaffHandlingSubject(String staff_id);
    public Set<String> getAllStaffIds();
    public Set<Staff> getAllStaff();
    public int getStaffHandlingOfASpecificClass(String subjectId, String classRoomId);
    public int getTotalNumberOfClassAllocatedToASimgleStaff(String staffId);
    //public Staff getStaffById(String staffId);
    
}
