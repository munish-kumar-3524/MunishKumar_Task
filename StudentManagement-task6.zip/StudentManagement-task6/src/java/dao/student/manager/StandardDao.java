/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.student.manager;

import connection.provider.ConnectionProvider;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import property.file.PropertiesData;

/**
 *
 * @author Munish kumar
 */
public class StandardDao implements StandardDaoInterface {
    private static final ConnectionProvider CONNECTION_PROVIDER = ConnectionProvider.getInstance();
    PropertiesData PropertiesData = new PropertiesData();
    SubjectDaoInterface subjectDao = new SubjectDao();
    StudentDaoInterface studentDao = new StudentDao();
    
    @Override
    public Set<String> getSetOfClassroomInOneStandard(String standardId) {
        Set<String> setOfClassRoomId = new HashSet<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_CLASSROOMID_BY_STANDARDID"));
            preparedStatement.setString(1, standardId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                String id = rs.getString(1);
                setOfClassRoomId.add(id);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return setOfClassRoomId;
    }

    @Override
    public String getStandardIdByStandardName(String standardName) {
        String standardId = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STANDARDID_BY_STANDARDNAME"));
            preparedStatement.setString(1, standardName);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                standardId = rs.getString(1);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return standardId;
    }

    @Override
    public Set<String> getAllStandardId() {
        Set<String> standardIds = new HashSet<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(PropertiesData.getPropertiseData("SELECT_ALL_STANDARD"));
            while(rs.next()){
                String id = rs.getString(1);
                standardIds.add(id);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return standardIds;
    }

    @Override
    public String getStandardNameByStandardId(String standardId) {
        String standardName = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STANDARDNAME_BY_STANDARDID"));
            preparedStatement.setString(1, standardId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                standardName = rs.getString(1);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return standardName;
    }

    @Override
    public Set<String> getTopScorerOfASubject(String subjectId, String standardId) {
        Set<String> setOfStudentsId = new HashSet<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_TOP_MARK_OF_A_SUBJECT"));
            preparedStatement.setString(1, subjectId);
            preparedStatement.setString(2, subjectId);
            preparedStatement.setString(3, standardId);
            preparedStatement.setString(4, standardId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                String id = rs.getString(1);
                setOfStudentsId.add(id);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return setOfStudentsId;
    }

    @Override
    public Map<String, Integer> getStudentAcadamicDetailsSubjectWise(String subjectId, String standardId) {
        Map<String, Integer> studentAndMark = new HashMap<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STUDENT_ACADAMICDETAILS_SUBJECTWISE"));
            preparedStatement.setString(1, subjectId);
            preparedStatement.setString(2, standardId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                String id = rs.getString("student_id");
                String name = studentDao.getStudentNameByStudentId(id);
                int mark = rs.getInt("subject_mark");
                studentAndMark.put(name, mark);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return studentAndMark;
    }

    @Override
    public Map<String, Integer> getCountOfSubjectOfStudentGreaterThenAverageMark(String standardId) {
        Map<String, Integer> studentAndCount = new HashMap<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("COUNT_OF_SUBJECT_OF_STUDENT_GREATER_THAN_AVERAGE_MARK"));
            preparedStatement.setString(1, standardId);
            preparedStatement.setString(2, standardId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                String id = rs.getString("student_id");
                String name = studentDao.getStudentNameByStudentId(id);
                int count = rs.getInt("count");
                studentAndCount.put(name, count);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(ClassRoomDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return studentAndCount;
    }

    
}
