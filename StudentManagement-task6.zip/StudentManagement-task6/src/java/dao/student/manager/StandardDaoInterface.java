/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao.student.manager;

import java.util.Map;
import java.util.Set;

/**
 *
 * @author Munish kumar
 */
public interface StandardDaoInterface {
    public Set<String> getSetOfClassroomInOneStandard(String standardId);
    public String getStandardIdByStandardName(String standardName);
    public String getStandardNameByStandardId(String standardId);
    public Set<String> getAllStandardId();
    public Set<String> getTopScorerOfASubject(String subjectId, String standardId);
    public Map<String, Integer> getStudentAcadamicDetailsSubjectWise(String subjectId, String standardId);
    public Map<String, Integer> getCountOfSubjectOfStudentGreaterThenAverageMark(String standardId);
    
}
