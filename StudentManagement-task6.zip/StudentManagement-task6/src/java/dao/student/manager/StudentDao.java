/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.student.manager;

import connection.provider.ConnectionProvider;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import student.management.ReportCard;
import student.management.Result;
import student.management.Student;
import property.file.PropertiesData;

/**
 *
 * @author Munish kumar
 */
public class StudentDao implements StudentDaoInterface {
    private static final ConnectionProvider CONNECTION_PROVIDER = ConnectionProvider.getInstance();
    PropertiesData PropertiesData = new PropertiesData();
    SubjectDaoInterface subjectDao = new SubjectDao();
    
    @Override
    public boolean insertStudent(Student student){
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("INSERT_STUDENT_SQL"));
            preparedStatement.setString(1, student.getId());
            preparedStatement.setString(2, student.getName());
            preparedStatement.setString(3, student.getPassword());
            int n = preparedStatement.executeUpdate();
            if(n == 0){
                flag = false;
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    @Override
    public boolean insertStudentAndTheirSubject(Student student) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            Set<String> setOfSubject = student.getSubjectsAndMarks().keySet();
            for(String subject : setOfSubject){
                PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("INSERT_STUDENT_AND_THEIR_SUBJECT_SQL"));
                preparedStatement.setString(1, student.getId());
                String subjectId = subjectDao.getSubjectIdBySubjectName(subject);
                preparedStatement.setString(2, subjectId);
                preparedStatement.setInt(3, student.getSubjectsAndMarks().get(subject));
                int n = preparedStatement.executeUpdate();
                if(n == 0){
                    flag = false;
                }
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    @Override
    public boolean updateStudentMark(String id, Map<String, Integer> subjectAndMark) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            for(String subject : subjectAndMark.keySet()){
                PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("UPDATE_STUDENT_MARK"));
                preparedStatement.setInt(1, subjectAndMark.get(subject));
                String subjectId = subjectDao.getSubjectIdBySubjectName(subject);
                preparedStatement.setString(2, subjectId);
                preparedStatement.setString(3, id);
                int n = preparedStatement.executeUpdate();
                if(n == 0){
                    flag = false;
                }
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    @Override
    public boolean insertStudentReportCard(String studentId, int totalmark, int averagemark, String result) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("INSERT_STUDENT_REPORTCARD"));
            preparedStatement.setString(1, studentId);
            preparedStatement.setInt(2, totalmark);
            preparedStatement.setInt(3, averagemark);
            preparedStatement.setString(4, result);
            int n = preparedStatement.executeUpdate();
            if(n == 0){
                flag = false;
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    @Override
    public int getTotalNumberOfStudent() {
        int totalNumberOfStudent = 0;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(PropertiesData.getPropertiseData("SELECT_COUNT_FROM_STUDENT"));
            boolean check = rs.next();
            if(!check){
                return 0;
            }
            totalNumberOfStudent = rs.getInt(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return totalNumberOfStudent;
    }
    
    @Override
    public int getSubjectMarkOfAStudent(String studentId, String subjectId) {
        int subjectMark = 0;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_SUBJECT_MARK_OF_A_STUDENT"));
            preparedStatement.setString(1, studentId);
            preparedStatement.setString(2, subjectId);
            ResultSet rs = preparedStatement.executeQuery();
            rs.next();
            subjectMark = rs.getInt(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return subjectMark;
    }
    
    @Override
    public HashMap<String, Integer> getStudentSubjectAndMark(String studentId) {
        HashMap<String, Integer> subjectAndMark = new HashMap<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_SUBJECT_AND_MARK_FROM_STUDENT_AND_THEIR_SUBJECT"));
            preparedStatement.setString(1, studentId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                String subjectId = rs.getString("subject_id");
                int mark = rs.getInt("subject_mark");
                String subjectName = subjectDao.getSubjectNameBySubjectId(subjectId);
                subjectAndMark.put(subjectName, mark);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return subjectAndMark;
    }
    
    @Override
    public ReportCard getStudentReportCard(String studentId) {
        ReportCard reportCard = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STUDENT_REPORTCARD"));
            preparedStatement.setString(1, studentId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                int totalMark = rs.getInt("totalmark");
                int averageMark = rs.getInt("averagemark");
                String result = rs.getString("result");
                int rank = rs.getInt("rank");
                ReportCard tempReportCard = new ReportCard(totalMark, averageMark, Result.valueOf(result), rank);
                reportCard = tempReportCard;
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return reportCard;
    }
    
    @Override
    public Student getStudentByStudentId(String studentId) {
        Student student = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STUDENT_BY_STUDENTID"));
            preparedStatement.setString(1, studentId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                String studentName = rs.getString("student_name");
                Student tempStudent = new Student(studentName, studentId);
                tempStudent.setReportCard(getStudentReportCard(studentId));
                HashMap<String, Integer> studentAndMark = getStudentSubjectAndMark(studentId);
                tempStudent.setSubjectsAndMarks(studentAndMark);
                student = tempStudent;
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return student;
    }
    
    @Override
    public Set<String> getStudentIdsInTheClass(String classRoomId) {
        Set<String> setOfStudents = new HashSet<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STUDENT_BY_CLASSROOMID"));
            preparedStatement.setString(1, classRoomId);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                String studentId = rs.getString("student_id");
                //Student student = getStudentByStudentId(studentId);
                setOfStudents.add(studentId);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return setOfStudents;
    }
    
    @Override
    public Set<String> getAllSubjectIds() {
        Set<String> setOfStudent = new HashSet<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(PropertiesData.getPropertiseData("SELECT_STUDENTID_FROM_STUDENT"));
            while(rs.next()){
                //String name = rs.getString("subject_name");
                String id = rs.getString("student_id");
                //Subject subject = new Subject(SubjectNames.valueOf(name), id);
                setOfStudent.add(id);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return setOfStudent;
    }
    
    @Override
    public boolean updateStudentReportCard(String studentId, int totalmark, int averagemark, String result) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("UPDATE_STUDENT_REPORTCARD"));
            preparedStatement.setString(4, studentId);
            preparedStatement.setInt(1, totalmark);
            preparedStatement.setInt(2, averagemark);
            preparedStatement.setString(3, result);
            int n = preparedStatement.executeUpdate();
            if(n == 0){
                flag = false;
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    @Override
    public String getStudentIdByStudentName(String studentName) {
        String studentId = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STUDENTID_BY_STUDENTNAME"));
            preparedStatement.setString(1, studentName);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            studentId = rs.getString(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return studentId;
    }
    
    @Override
    public String getStudentNameByStudentId(String studentId) {
        String studentName = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STUDENTNAME_BY_STUDENTID"));
            preparedStatement.setString(1, studentId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            studentName = rs.getString(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return studentName;
    }
    
    @Override
    public String getStudentPasswordByStudentId(String studentId) {
        String studentName = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_STUDENTPASSWORD_BY_STUDENTID"));
            preparedStatement.setString(1, studentId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            studentName = rs.getString(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return studentName;
    }
    
    @Override
    public boolean updateStudentMark(String studentId, String subjectId, int mark) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("UPDATE_STUDENT_MARK"));
            preparedStatement.setInt(1, mark);
            preparedStatement.setString(2, studentId);
            preparedStatement.setString(3, subjectId);
            int n = preparedStatement.executeUpdate();
            if(n == 0){
                flag = false;
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    @Override
    public int getTopMarkOfAStudent(String studentId){
        int topMark = 0;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_TOP_MARK_OF_A_STUDENT"));
            preparedStatement.setString(1, studentId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return 0;
            }
            topMark = rs.getInt(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return topMark;
    }

    @Override
    public boolean updateStudentRank(Student student) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("UPDATE_STUDENT_RANK"));
            preparedStatement.setInt(1, student.getReportCard().getRank());
            preparedStatement.setString(2, student.getId());
            int n = preparedStatement.executeUpdate();
            if(n == 0){
                flag = false;
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
}
