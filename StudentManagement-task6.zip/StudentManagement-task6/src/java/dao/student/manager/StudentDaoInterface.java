/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao.student.manager;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import student.management.ReportCard;
import student.management.Student;

/**
 *
 * @author Munish kumar
 */
public interface StudentDaoInterface {
    
    public boolean insertStudent(Student student) ;
    public boolean insertStudentAndTheirSubject(Student student) ;
    public boolean insertStudentReportCard(String studentId, int totalmark, int averagemark, String result);
    public int getTotalNumberOfStudent() ;
    public int getSubjectMarkOfAStudent(String studentId, String subjectId) ;
    public HashMap<String, Integer> getStudentSubjectAndMark(String studentId) ;
    public ReportCard getStudentReportCard(String studentId);
    public Student getStudentByStudentId(String studentId);
    public Set<String> getStudentIdsInTheClass(String classRoomId);
    public Set<String> getAllSubjectIds();
    public boolean updateStudentReportCard(String studentId, int totalmark, int averagemark, String result);
    public String getStudentIdByStudentName(String studentName);
    public String getStudentNameByStudentId(String studentId);
    public String getStudentPasswordByStudentId(String studentId);
    public boolean updateStudentMark(String studentId, String subjectId, int mark);
    public int getTopMarkOfAStudent(String studentId);
    public boolean updateStudentRank(Student student);
    public boolean updateStudentMark(String id, Map<String, Integer> subjectAndMark);
}
