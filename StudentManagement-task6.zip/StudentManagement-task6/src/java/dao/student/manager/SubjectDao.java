/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.student.manager;

import student.management.Subject;
import connection.provider.ConnectionProvider;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import student.management.SubjectNames;
import property.file.PropertiesData;

/**
 *
 * @author Munish kumar
 */
public class SubjectDao implements SubjectDaoInterface {
    private static final ConnectionProvider CONNECTION_PROVIDER = ConnectionProvider.getInstance();
    PropertiesData PropertiesData = new PropertiesData();
    
    @Override
    public boolean insertSubject(Subject subject) {
        boolean flag = true;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("INSERT_SUBJECT_SQL"));
            preparedStatement.setString(1, subject.getId());
            preparedStatement.setString(2, subject.getName().toString());
            int n = preparedStatement.executeUpdate();
            if(n == 0){
                flag = false;
            }
        }catch (SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(SubjectDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    @Override
    public List<String> getAllSubjectNames() {
        List<String> listOfSubjectNames = new ArrayList<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(PropertiesData.getPropertiseData("SELECT_SUBJECT_NAME_SQL"));
            while(rs.next()){
                listOfSubjectNames.add(rs.getString("subject_name"));
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(SubjectDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listOfSubjectNames;
    }
    
    @Override
    public Set<String> getAllSubjectIds() {
        Set<String> setOfSubjects = new HashSet<>();
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(PropertiesData.getPropertiseData("SELECT_SUBJECT_SQL"));
            while(rs.next()){
                //String name = rs.getString("subject_name");
                String id = rs.getString("subject_id");
                //Subject subject = new Subject(SubjectNames.valueOf(name), id);
                setOfSubjects.add(id);
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(SubjectDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return setOfSubjects;
    }
    
    @Override
    public String getSubjectIdBySubjectName(String subjectName) {
        String subjectId = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_SUBJECTID_BY_NAME_SQL"));
            preparedStatement.setString(1, subjectName);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            subjectId = rs.getString(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(SubjectDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return subjectId;
    }
    
    @Override
    public String getSubjectNameBySubjectId(String subjectId) {
        String subjectName = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_SUBJECTNAME_BY_ID_SQL"));
            preparedStatement.setString(1, subjectId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            subjectName = rs.getString(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(SubjectDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return subjectName;
    }
    
    @Override
    public Subject getSubjectBySubjectId(String subject_id) {
        Subject subject = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_SUBJECT_FROM_SUBJECTID_SQL"));
            preparedStatement.setString(1, subject_id);
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                String name = rs.getString("subject_name");
                String id = rs.getString("subject_id");
                Subject tempSubject = new Subject(SubjectNames.valueOf(name), id);
                subject = tempSubject;
            }
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(SubjectDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return subject;
    }
}
