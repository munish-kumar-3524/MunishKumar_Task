/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao.student.manager;

import java.util.List;
import java.util.Set;
import student.management.Subject;

/**
 *
 * @author Munish kumar
 */
public interface SubjectDaoInterface {
    
    public boolean insertSubject(Subject subject) ;
    public List<String> getAllSubjectNames() ;
    public Set<String> getAllSubjectIds() ;
    public String getSubjectIdBySubjectName(String subjectName) ;
    public String getSubjectNameBySubjectId(String subjectId) ;
    public Subject getSubjectBySubjectId(String subject_id) ;
    
}
