/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.student.manager;

import connection.provider.ConnectionProvider;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import property.file.PropertiesData;

/**
 *
 * @author Munish kumar
 */
public class UserAndPasswordDao implements UserAndPasswordDaoInterface {
    private static final ConnectionProvider CONNECTION_PROVIDER = ConnectionProvider.getInstance();
    PropertiesData PropertiesData = new PropertiesData();
    
    @Override
    public String getPassword(String userId){
        String password = null;
        try{
            Connection connection = CONNECTION_PROVIDER.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(PropertiesData.getPropertiseData("SELECT_PASSWORD_BY_ID"));
            preparedStatement.setString(1, userId);
            ResultSet rs = preparedStatement.executeQuery();
            boolean check = rs.next();
            if(!check){
                return null;
            }
            password = rs.getString(1);
        }catch(SQLException e){
            System.out.println(e);
        } catch (IOException ex) {
            Logger.getLogger(UserAndPasswordDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return password;
    }
}
