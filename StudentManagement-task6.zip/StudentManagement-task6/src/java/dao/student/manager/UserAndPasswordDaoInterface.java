/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao.student.manager;

/**
 *
 * @author Munish kumar
 */
public interface UserAndPasswordDaoInterface {
    public String getPassword(String userId);
}
