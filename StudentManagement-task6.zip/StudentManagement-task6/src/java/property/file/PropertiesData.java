/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package property.file;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

/**
 *
 * @author Munish kumar
 */
public class PropertiesData {
    Properties p = new Properties();
    
    /**
     *
     * @param key
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public String getPropertiseData(String key) throws FileNotFoundException, IOException{
        FileReader fis = new FileReader("C:\\Users\\Munish kumar\\Documents\\NetBeansProjects\\StudentManagement-task6\\src\\java\\property\\file\\StudentManagementDatabaseDetails.properties");
        p.load(fis);
        return p.getProperty(key).trim();
    }
}
