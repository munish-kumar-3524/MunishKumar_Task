/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package random.generator.studentmanagement;
import java.util.Random;
/**
 *
 * @author Munish kumar
 */
public class RandomGenerator {
    private final static String LOWERCASE = "abcdefghijklmnopqrstuvwxyz";
    private final static String UPPERCASE = "AVCDEFGHIJKLMNOPQRSTUVWXYZ";
    private final static String ALPHABET = "abcdefghijklmnopqrstuvwxyzAVCDEFGHIJKLMNOPQRSTUVWXYZ";
    private final static String ALPHANUMERIC = "abcdefghijklmnopqrstuvwxyzAVCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    
    public static int generateMark(){
        Random r = new Random();
        return r.nextInt(100 - 45) + 45;
    }
    
    public static String generateId(){
        String temporaryString = "";
        for(int i=0;i<6;i++){
            Random r = new Random();
            int temp = r.nextInt(62);
            temporaryString += ALPHANUMERIC.charAt(temp);
        }
        return temporaryString;
    }
    
    public static String generateName(){
        Random r = new Random();
        String temporaryString = "";
        temporaryString += UPPERCASE.charAt(r.nextInt(26));
        for(int i=0;i<7;i++){
            r = new Random();
            int temp = r.nextInt(26);
            temporaryString += LOWERCASE.charAt(temp);
        }
        return temporaryString;
    }
    
    public static String generateClassName(){
        Random r = new Random();
        String temporaryString = "";
        for(int i=0;i<3;i++){
            temporaryString += UPPERCASE.charAt(r.nextInt(26));
        }
        return temporaryString;
    }
    
}
