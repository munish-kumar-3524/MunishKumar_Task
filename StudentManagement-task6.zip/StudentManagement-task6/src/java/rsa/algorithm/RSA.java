/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rsa.algorithm;

import connection.provider.ConnectionProvider;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;
import javax.crypto.Cipher;

/**
 *
 * @author Munish kumar
 */
public class RSA {
    private static PrivateKey privateKey;
    private static PublicKey publicKey;
    static RSA rsa = null;
    private RSA(){}
    public static void RSAinitlizer(){
        try{
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(1024);
            KeyPair pair = generator.genKeyPair();
            privateKey = pair.getPrivate();
            publicKey = pair.getPublic();
        }catch(Exception e){} 
    }
    
    public static RSA getInstance(){
        if(rsa == null){
            RSAinitlizer();
            rsa = new RSA();
        }
        return rsa;
    }
    
    public String encrypt(String message) throws Exception{
        byte[] messageToBytes = message.getBytes();
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE,publicKey);
        byte[] encryptedByte = cipher.doFinal(messageToBytes);
        return encode(encryptedByte);
    }
    
    private String encode(byte[] data){
        return Base64.getEncoder().encodeToString(data);
    }
    
    public String decrypt(String encryptedMessage) throws Exception{
        byte[] encryptedBytes = decode(encryptedMessage);
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE,privateKey);
        byte[] decryptedByte = cipher.doFinal(encryptedBytes);
        return new String(decryptedByte, "UTF8");
    }
    
    private byte[] decode(String data){
        return Base64.getDecoder().decode(data);
    }
}
