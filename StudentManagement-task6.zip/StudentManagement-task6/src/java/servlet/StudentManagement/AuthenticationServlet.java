/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet.StudentManagement;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.student.manager.UserAndPasswordDao;
import dao.student.manager.StudentDao;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import dao.student.manager.StaffDao;
import dao.student.manager.AdminDao;
import dao.student.manager.AdminDaoInterface;
import dao.student.manager.StaffDaoInterface;
import dao.student.manager.StudentDaoInterface;
import dao.student.manager.UserAndPasswordDaoInterface;
import java.util.logging.Level;
import java.util.logging.Logger;
import rsa.algorithm.RSA;
/**
 *
 * @author Munish kumar
 */
public class AuthenticationServlet extends HttpServlet {

    static final UserAndPasswordDaoInterface USER_AND_PASSWORD = new UserAndPasswordDao();
    static final StudentDaoInterface STUDENT_DAO = new StudentDao();
    static final StaffDaoInterface STAFF_DAO = new StaffDao();
    static final AdminDaoInterface ADMIN_DAO = new AdminDao();
    RSA rsa = RSA.getInstance();
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
        switch(action){
            case "/login":
            {
                try {
                    login(request, response);
                } catch (Exception ex) {
                    Logger.getLogger(AuthenticationServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                break;


            case "/forgotPassword":
                forgotPassword(request, response);
                break;
            case "/logout" :
                logout(request, response);
                break;
        }
    }
    
    protected void login(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        PrintWriter out = response.getWriter();
        String userId = request.getParameter("id");
        String userPassword = request.getParameter("password");
        String password = USER_AND_PASSWORD.getPassword(userId);
        HttpSession session = request.getSession();
        if((password == null || !password.equals(userPassword))){
            out.println("error");
        }else if(STUDENT_DAO.getStudentNameByStudentId(userId) != null){
            session.setAttribute("userId", userId);
            RequestDispatcher rd = request.getRequestDispatcher("Student.jsp");
            rd.forward(request, response);
        }else if(STAFF_DAO.getStaffNameByStaffId(userId) != null){
            session.setAttribute("userId", userId);
            RequestDispatcher rd = request.getRequestDispatcher("Staff.jsp");
            rd.forward(request, response);
        }else if(ADMIN_DAO.getAdminNameByAdminId(userId) != null){
            session.setAttribute("userId", userId);
            RequestDispatcher rd = request.getRequestDispatcher("Admin.jsp");
            rd.forward(request, response);
        }
    }
    
    protected void forgotPassword(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
        String userId = request.getParameter("id");
        HttpSession session = request.getSession();
        if(STUDENT_DAO.getStudentNameByStudentId(userId) != null){
            String password = STUDENT_DAO.getStudentPasswordByStudentId(userId);
            session.setAttribute("password", password);
            RequestDispatcher rd = request.getRequestDispatcher("ForgotPassword.jsp");
            rd.forward(request, response);
        }else if(STAFF_DAO.getStaffNameByStaffId(userId) != null){
            String password = STAFF_DAO.getStaffPasswordByStaffId(userId);
            session.setAttribute("password", password);
            RequestDispatcher rd = request.getRequestDispatcher("ForgotPassword.jsp");
            rd.forward(request, response);
        }else if(ADMIN_DAO.getAdminNameByAdminId(userId) != null){
            String password = ADMIN_DAO.getAdminPasswordByAdminId(userId);
            session.setAttribute("password", password);
            RequestDispatcher rd = request.getRequestDispatcher("ForgotPassword.jsp");
            rd.forward(request, response);
        }else{
            String password = null;
            session.setAttribute("password", password);
            RequestDispatcher rd = request.getRequestDispatcher("ForgotPassword.jsp");
            rd.forward(request, response);
        }
    }

    private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        session.removeAttribute("userId");
        response.sendRedirect("Login.jsp");
    }
}
