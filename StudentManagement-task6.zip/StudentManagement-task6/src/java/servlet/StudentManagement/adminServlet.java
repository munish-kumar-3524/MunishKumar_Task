/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet.StudentManagement;

import dao.student.manager.StaffDao;
import dao.student.manager.StaffDaoInterface;
import dao.student.manager.StandardDao;
import dao.student.manager.StandardDaoInterface;
import dao.student.manager.StudentDao;
import dao.student.manager.StudentDaoInterface;
import dao.student.manager.SubjectDao;
import dao.student.manager.SubjectDaoInterface;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import student.management.MarkRegister;
import student.management.Staff;
import student.management.Standard;
import student.management.Student;
import rsa.algorithm.RSA;

/**
 *
 * @author Munish kumar
 */
public class adminServlet extends HttpServlet {
    SubjectDaoInterface subjectDao = new SubjectDao();
    StudentDaoInterface studentDao = new StudentDao();
    StaffDaoInterface staffDao = new StaffDao();
    StandardDaoInterface standardDao = new StandardDao();
    //PrintWriter out = response.getWriter();
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        String action = request.getServletPath();
        switch(action){
            case "/addStudent":
                setStudentData(request, response);
                break;
            case "/addStaff":
                setStaffData(request, response);
                break;
            case "/studentsStandardWise":
                getStudentsStandardWise(request, response);
                break;
            case "/averageMarkOfEachSubject":
                getAverageMarkOfEachSubject(request, response);
                break;
            case "/studentsGreaterThanAveragemark":
                getStudentsGreaterThanAveragemark(request, response);
                break;
            case "/topMarkOfASubject":
                getTopScorerOfASubject(request, response);
                break;
            case "/studentsDetailsSubjectWise":
                getStudentsDetailsSubjectWise(request, response);
                break;
            case "/countOfSubjectOfStudentGreaterThanAveragemark":
                getCountOfSubjectOfStudentGreaterThanAveragemark(request, response);
                break;
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(adminServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(adminServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void setStudentData(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException, Exception{
        String studentId = request.getParameter("studentId");
        String studentName = request.getParameter("studentName");
        String studentPassword = request.getParameter("studentPassword");
        //String encryptedPassword = rsa.encrypt(studentPassword);
        String studentStandard = request.getParameter("standard");
        List<String> listOfSubjectNames = subjectDao.getAllSubjectNames();
        HashMap<String, Integer>  subjectAndMark = new HashMap<>();
        for(String subject : listOfSubjectNames){
            subjectAndMark.put(subject, Integer.parseInt(request.getParameter(subject)));
        }
        Student student = new Student(studentName, studentId, studentPassword);
        student.setSubjectsAndMarks(subjectAndMark);
        studentDao.insertStudent(student);
        studentDao.insertStudentAndTheirSubject(student);
        Standard.setStudentsReportCardDetails(student);
        Standard.setStudentToClass(student, studentStandard);
        request.setAttribute("studentName", studentName);
        RequestDispatcher rd = request.getRequestDispatcher("AddStudent.jsp");
        rd.forward(request, response);
    }

    private void setStaffData(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException, Exception {
        String staffId = request.getParameter("staffId");
        String staffName = request.getParameter("staffName");
        String staffPassword = request.getParameter("staffPassword");
        //String encryptedPassword = rsa.encrypt(staffPassword);
        String[] subjects = request.getParameterValues("subject");
        Set<String> setOfSubjects = new HashSet<>();
        setOfSubjects.addAll(Arrays.asList(subjects));
        Staff staff = new Staff(staffName, staffId, staffPassword);
        staff.setHandlingSubjects(setOfSubjects);
        
        staffDao.insertStaff(staff);
        staffDao.insertStaffHandlingSubject(staff);
        Standard.setStaffToClass(staff);
        
        request.setAttribute("staffName", staffName);
        RequestDispatcher rd = request.getRequestDispatcher("AddStaff.jsp");
        rd.forward(request, response);
    }

    private void getStudentsStandardWise(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String standardId = request.getParameter("standard");
        TreeMap<String, List<Student>> classesWithStudent =  MarkRegister.getAllStudentRankWiseByStandard(standardId);
        request.setAttribute("classesWithStudent", classesWithStudent);
        RequestDispatcher rd = request.getRequestDispatcher("ShowAllStudentByStandard.jsp");
        rd.forward(request, response);
    }

    private void getAverageMarkOfEachSubject(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String standardId = request.getParameter("standard");
        HashMap<String, String> averageMarkOfEachSubject =  MarkRegister.getOverAllAverageMarkOfEachSubject(standardId);
        request.setAttribute("averageMarkOfEachSubject", averageMarkOfEachSubject);
        RequestDispatcher rd = request.getRequestDispatcher("OverallAverageMarkOfEachSubject.jsp");
        rd.forward(request, response);
    }

    private void getStudentsGreaterThanAveragemark(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String SubjectName = request.getParameter("subject");
        Map<String, List<String>> subjectAndStudents = MarkRegister.getListOfStudentsGreaterthanOrEqualtoAverageMark(SubjectName);
        request.setAttribute("subjectAndStudents", subjectAndStudents);
        RequestDispatcher rd = request.getRequestDispatcher("StudentsGreaterThanAverageMark.jsp");
        rd.forward(request, response);
    }

    private void getTopScorerOfASubject(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String standardId = request.getParameter("standard");
        String SubjectName = request.getParameter("subject");
        String subjectId = subjectDao.getSubjectIdBySubjectName(SubjectName);
        Set<String> setOfStudentsId = standardDao.getTopScorerOfASubject(subjectId, standardId);
        List<String> listOfStudents = new ArrayList<>();
        for(String id : setOfStudentsId){
            String name = studentDao.getStudentNameByStudentId(id);
            listOfStudents.add(name);
        }        
        request.setAttribute("listOfStudents", listOfStudents);
        RequestDispatcher rd = request.getRequestDispatcher("TopScorerOfASubject.jsp");
        rd.forward(request, response);
    }

    
    private void getStudentsDetailsSubjectWise(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String standardId = request.getParameter("standard");
        String SubjectName = request.getParameter("subject");
        String subjectId = subjectDao.getSubjectIdBySubjectName(SubjectName);
        Map<String, Integer> studentAndMark = standardDao.getStudentAcadamicDetailsSubjectWise(subjectId, standardId);
        request.setAttribute("studentAndMark", studentAndMark);
        RequestDispatcher rd = request.getRequestDispatcher("StudentDetailsSubjectWise.jsp");
        rd.forward(request, response);
    }
    
    private void getCountOfSubjectOfStudentGreaterThanAveragemark(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String standardId = request.getParameter("standard");
        Map<String, Integer> studentAndMark = standardDao.getCountOfSubjectOfStudentGreaterThenAverageMark(standardId);
        request.setAttribute("studentAndMark", studentAndMark);
        RequestDispatcher rd = request.getRequestDispatcher("CountOfSubjectOfStudentGreaterThanAverageMark.jsp");
        rd.forward(request, response);
    }
}
