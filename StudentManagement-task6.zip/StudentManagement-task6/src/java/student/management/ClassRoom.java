/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package student.management;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Munish kumar
 */
public class ClassRoom {
    private String id;
    private String name;
    private final HashMap<String, String> subjectsAndStaffs;
    private Set<String> students; 

    public ClassRoom(String id, String name) {
        this.id = id;
        this.name = name;
        this.subjectsAndStaffs = new HashMap<>();
        this.students = new HashSet<>();
    }

    public void setStudents(Set<String> students) {
        this.students = students;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public HashMap<String, String> getSubjectAndStaff() {
        return (HashMap<String, String>) subjectsAndStaffs.clone();
    }

    public void setSubjectAndStaff(String subject, String staff) {
        this.subjectsAndStaffs.put(subject, staff);
    }

    public Set<String> getStudents() {
        return students;
    }

    public void setStudentsRankWise(String student) {
        this.students.add(student);
    }
}
