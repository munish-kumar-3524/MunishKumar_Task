/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package student.management;

import dao.student.manager.ClassRoomDao;
import dao.student.manager.ClassRoomDaoInterface;
import dao.student.manager.StandardDao;
import dao.student.manager.StandardDaoInterface;
import dao.student.manager.StudentDao;
import dao.student.manager.StudentDaoInterface;
import dao.student.manager.SubjectDao;
import dao.student.manager.SubjectDaoInterface;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author Munish kumar
 */
public class MarkRegister {
    
    private static final SubjectDaoInterface SUBJECT_DAO = new SubjectDao();
    private static final ClassRoomDaoInterface CLASSROOM_DAO = new ClassRoomDao();
    private static final StudentDaoInterface STUDENT_DAO = new StudentDao();
    private static final StandardDaoInterface STANDARD_DAO = new StandardDao();
    
    private static void generateRank(TreeMap<Integer, Set<Student>> studentsMarkWise){
        Set<Integer> setOfMark = studentsMarkWise.keySet();
        List<Integer> listOfMark = new ArrayList<>();
        listOfMark.addAll(setOfMark);
        Collections.reverse(listOfMark);
        int i = 1, j = 1;
        for(Integer totalMark : listOfMark){
            Set<Student> setOfStudent = studentsMarkWise.get(totalMark);
            for(Student student : setOfStudent){
                if(student.getReportCard().getResult().toString().equals("FAIL")){
                    student.getReportCard().setRank(0);
                    STUDENT_DAO.updateStudentRank(student);
                    j--;
                }else{
                    student.getReportCard().setRank(i);
                    STUDENT_DAO.updateStudentRank(student);
                }
                j++;
            }
            i = j;
        }
    }
    
    private static List<Student> arrangeStudentRankWise(Set<Student> students){
        TreeMap<Integer, Set<Student>> studentsMarkWise = new TreeMap<>();
        for(Student student : students){
            if(studentsMarkWise.containsKey(student.getReportCard().getTotalMark())){
                Set<Student> setOfStudent = studentsMarkWise.get(student.getReportCard().getTotalMark());
                setOfStudent.add(student);
                studentsMarkWise.put(student.getReportCard().getTotalMark(), setOfStudent);
            }else{
                Set<Student> setOfStudent = new HashSet<>();
                setOfStudent.add(student);
                studentsMarkWise.put(student.getReportCard().getTotalMark(), setOfStudent);
            }
        }
        generateRank(studentsMarkWise);
        TreeMap<Integer, Set<Student>> studentsRankWise = new TreeMap<>();
        for(Student student : students){
            if(studentsRankWise.containsKey(student.getReportCard().getRank())){
                Set<Student> setOfStudent = studentsRankWise.get(student.getReportCard().getRank());
                setOfStudent.add(student);
                studentsRankWise.put(student.getReportCard().getRank(), setOfStudent);
            }else{
                Set<Student> setOfStudent = new HashSet<>();
                setOfStudent.add(student);
                studentsRankWise.put(student.getReportCard().getRank(), setOfStudent);
            }
        }
        Set<Integer> setOfRank = studentsRankWise.keySet();
        List<Student> listOfStudents = new ArrayList<>();
        for(Integer rank : setOfRank){
            Set<Student> setOfStudent = studentsRankWise.get(rank);
            for(Student student : setOfStudent){
                listOfStudents.add(student);
            }
        }
        return listOfStudents;
    }
    
    public static TreeMap<String, List<Student>> getAllStudentRankWiseByStandard(String standardId){
        TreeMap<String, List<Student>> classesWithStudents = new TreeMap<>();
        Set<String> setOfClassRoom =  STANDARD_DAO.getSetOfClassroomInOneStandard(standardId);
        for(String classRoomId : setOfClassRoom){
            Set<String> setOfStudentIds = CLASSROOM_DAO.getStudentIdsByClassRoomId(classRoomId);
            Set<Student> setOfStudents = new HashSet<>();
            for(String studentId : setOfStudentIds){
                Student student = STUDENT_DAO.getStudentByStudentId(studentId);
                setOfStudents.add(student);
            }
            classesWithStudents.put(classRoomId, arrangeStudentRankWise(setOfStudents));
        }
        return classesWithStudents;
    }
    
    public static String getOverallPassPercentage() throws SQLException, IOException{
        Set<String> setOfStudentIds = STUDENT_DAO.getAllSubjectIds();
        Set<Student> setOfStudents = new HashSet<>();
        for(String studentId : setOfStudentIds){
            Student student = STUDENT_DAO.getStudentByStudentId(studentId);
            setOfStudents.add(student);
        }
        if(setOfStudents.isEmpty()){
            return null;
        }
        int passCount = 0;
        int failCount = 0;
        String passPercentage;
        for(Student student : setOfStudents){
            if(student.getReportCard().getResult().toString().equals("PASS")){
                passCount++;
            }else{
                failCount++;
            }
        }
        passPercentage = String.format("%.1f", ((float)passCount/(float)(passCount+failCount))*100);
        return passPercentage;
    }

    public static HashMap<String, String> getPassPercentageForEachClass() throws SQLException, IOException{
        HashMap<String, String> ClassesAndPassPercentage = new HashMap<>();
        Set<String> classRooms = CLASSROOM_DAO.getAllClassRoomId();
        for(String classroom : classRooms){
            Set<String> setOfStudentIds = CLASSROOM_DAO.getStudentIdsByClassRoomId(classroom);
            Set<Student> setOfStudents = new HashSet<>();
            for(String studentId : setOfStudentIds){
                Student student = STUDENT_DAO.getStudentByStudentId(studentId);
                setOfStudents.add(student);
            }
            int passCount = 0;
            int failCount = 0;
            String passPercentage;
            for(Student student : setOfStudents){
                if(student.getReportCard().getResult().toString().equals("PASS")){
                    passCount++;
                }else{
                    failCount++;
                }
            }
            passPercentage = String.format("%.1f", ((float)passCount/(float)(passCount+failCount))*100);
            ClassesAndPassPercentage.put(CLASSROOM_DAO.getClassRoomNameByClassRoomId(classroom), passPercentage);
        }
        
        return ClassesAndPassPercentage;
    }

    public static TreeMap<String, List<Student>> getStudentsClassWise() throws SQLException, IOException{
        TreeMap<String, List<Student>> classesWithStudents = new TreeMap<>();
        Set<String> classRooms = CLASSROOM_DAO.getAllClassRoomId();
        for(String classRoom : classRooms){
            
            Set<String> setOfStudentIds = CLASSROOM_DAO.getStudentIdsByClassRoomId(classRoom);
            Set<Student> setOfStudents = new HashSet<>();
            for(String studentId : setOfStudentIds){
                Student student = STUDENT_DAO.getStudentByStudentId(studentId);
                setOfStudents.add(student);
            }
            List<Student> listOfStudents = new ArrayList<>();
            listOfStudents.addAll(arrangeStudentRankWise(setOfStudents));
            classesWithStudents.put(classRoom, listOfStudents);
        }
        return (TreeMap<String, List<Student>>) classesWithStudents.clone();
    }
    
    public static void setRankForStudentInClass(String classRoomId){

            Set<String> setOfStudentIds = CLASSROOM_DAO.getStudentIdsByClassRoomId(classRoomId);
            Set<Student> setOfStudents = new HashSet<>();
            for(String studentId : setOfStudentIds){
                Student student = STUDENT_DAO.getStudentByStudentId(studentId);
                setOfStudents.add(student);
            }
            arrangeStudentRankWise(setOfStudents);
    }

    public static HashMap<String, String> getOverAllAverageMarkOfEachSubject(String standardId){
        
        Set<Student> setOfStudents = new HashSet<>();
        Set<String> setOfClassRoom =  STANDARD_DAO.getSetOfClassroomInOneStandard(standardId);
        for(String classRoomId : setOfClassRoom){
            Set<String> setOfStudentIds = CLASSROOM_DAO.getStudentIdsByClassRoomId(classRoomId);
            for(String studentId : setOfStudentIds){
                Student student = STUDENT_DAO.getStudentByStudentId(studentId);
                setOfStudents.add(student);
            }
        }
        List<String> setOfSubject = SUBJECT_DAO.getAllSubjectNames();
        HashMap<String, String> subjectsAndItsAverageMark = new HashMap<>();
        for(String subject : setOfSubject){
            int totalMarkOfEachSubject = 0;
            for(Student student : setOfStudents){
                totalMarkOfEachSubject += student.getSubjectsAndMarks().get(subject);//
            }
            float averageMark  = (float)totalMarkOfEachSubject/(float)setOfStudents.size();
            String average = String.format("%.1f", averageMark);
            subjectsAndItsAverageMark.put(subject, average);
        }
        return subjectsAndItsAverageMark;
    }

    private static int getAverageMarkOfASubject(String subject, String standard) {
        int totalMark = 0;
        Set<Student> setOfStudents = new HashSet<>();
        Set<String> setOfClassRoom =  STANDARD_DAO.getSetOfClassroomInOneStandard(standard);
        for(String classRoomId : setOfClassRoom){
            Set<String> setOfStudentIds = CLASSROOM_DAO.getStudentIdsByClassRoomId(classRoomId);
            for(String studentId : setOfStudentIds){
                Student student = STUDENT_DAO.getStudentByStudentId(studentId);
                setOfStudents.add(student);
            }
        }
        for(Student student : setOfStudents){
            totalMark += student.getSubjectsAndMarks().get(subject);
        }
        return totalMark/STUDENT_DAO.getTotalNumberOfStudent();
    }

    public static TreeMap<String,List<String>> getListOfStudentsGreaterthanOrEqualtoAverageMark(String subjectName){
        TreeMap<String, List<String>> subjectWithStudents = new TreeMap<>();
        Set<String> setOfStandard = STANDARD_DAO.getAllStandardId();
        for(String standard : setOfStandard){
            List<String> studentNames = new ArrayList<>();
            Set<Student> setOfStudents = new HashSet<>();
            Set<String> setOfClassRoom =  STANDARD_DAO.getSetOfClassroomInOneStandard(standard);
            for(String classRoomId : setOfClassRoom){
                Set<String> setOfStudentIds = CLASSROOM_DAO.getStudentIdsByClassRoomId(classRoomId);
                for(String studentId : setOfStudentIds){
                    Student student = STUDENT_DAO.getStudentByStudentId(studentId);
                    setOfStudents.add(student);
                }
            }
            int averageMark = getAverageMarkOfASubject(subjectName, standard);
            for(Student student : setOfStudents){
                if(student.getSubjectsAndMarks().get(subjectName) > averageMark){
                    studentNames.add(student.getName());
                }
            }
            String standardName = STANDARD_DAO.getStandardNameByStandardId(standard);
            subjectWithStudents.put(standardName, studentNames);
        }
        return subjectWithStudents;
    }

//    private static int getTopScoreOfASubject(String subject, String standard) throws SQLException, IOException{
//        int topScore = 0;
//        Set<Student> setOfStudents = new HashSet<>();
//        Set<String> setOfClassRoom =  STANDARD_DAO.getSetOfClassroomInOneStandard(standard);
//        for(String classRoomId : setOfClassRoom){
//            Set<String> setOfStudentIds = CLASSROOM_DAO.getStudentIdsByClassRoomId(classRoomId);
//            for(String studentId : setOfStudentIds){
//                Student student = STUDENT_DAO.getStudentByStudentId(studentId);
//                setOfStudents.add(student);
//            }
//        }
//        
//        for(Student student : setOfStudents){
//            if(student.getSubjectsAndMarks().get(subject) > topScore){
//                topScore = student.getSubjectsAndMarks().get(subject);
//            }
//        }
//        return topScore;
//    }
  
//    public static HashMap<String, List<String>> getTopScorerOfEachSubject(String standard) throws SQLException, IOException{
//        HashMap<String, List<String>> topScorersOfEachSubject = new HashMap<>();
//        Set<String> setOfSubjects = SUBJECT_DAO.getAllSubjectIds();
//        
//        Set<String> setOfStudentIds = STUDENT_DAO.getAllSubjectIds();
//        Set<Student> setOfStudents = new HashSet<>();
//        for(String studentId : setOfStudentIds){
//            Student student = STUDENT_DAO.getStudentByStudentId(studentId);
//            setOfStudents.add(student);
//        }
//        
//        for(String subject : setOfSubjects){
//            int topScore = getTopScoreOfASubject(subject);//
//            List<String> topScorers = new ArrayList<>();
//            for(Student student : setOfStudents){
//                if(student.getSubjectsAndMarks().get(subject) == topScore){
//                    topScorers.add(student.getName());
//                }
//            }
//            topScorersOfEachSubject.put(SUBJECT_DAO.getSubjectNameBySubjectId(subject), topScorers);
//        }
//        return topScorersOfEachSubject;
//    }

    
    public static HashMap<String, Integer> getStudentAcadamicDetailsSubjectWise(String subjectName) throws SQLException, IOException{
        HashMap<String, Integer> namesAndMarks = new HashMap<>();
        Set<String> setOfSubjects = SUBJECT_DAO.getAllSubjectIds();
        String subject = null;
        for(String tempSubject : setOfSubjects){
            if(SUBJECT_DAO.getSubjectIdBySubjectName(subjectName.toUpperCase()).equals(tempSubject)){
                subject = tempSubject;
            }
        }
        if(subject == null) return null;
        Set<String> setOfStudentIds = STUDENT_DAO.getAllSubjectIds();
        Set<Student> setOfStudents = new HashSet<>();
        for(String studentId : setOfStudentIds){
            Student student = STUDENT_DAO.getStudentByStudentId(studentId);
            setOfStudents.add(student);
        }
        
        for(Student student : setOfStudents){
            namesAndMarks.put(student.getName(), student.getSubjectsAndMarks().get(subject));
        }
        
        return namesAndMarks;
    }
   
    public static HashMap<String, Integer> getCountOfStudentsGreaterthanOrEqualtoAverageMarkForEachSubjects() throws SQLException, IOException{
        HashMap<String, Integer> SubjectNameAndCount = new HashMap<>();
        Set<String> setOfSubjects = SUBJECT_DAO.getAllSubjectIds();
        for(String subject : setOfSubjects){
            String subjectName = SUBJECT_DAO.getSubjectNameBySubjectId(subject);
            SubjectNameAndCount.put(subjectName, getListOfStudentsGreaterthanOrEqualtoAverageMark(subjectName).size());
        }
        
        return SubjectNameAndCount;
    }
}
