/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package student.management;

/**
 *
 * @author Munish kumar
 */
public class ReportCard {
    private int totalMark;
    private int rank;
    private int averageMark;
    private Result result;

    public ReportCard(int totalMark, int average, Result result, int rank) {
        this.totalMark = totalMark;
        this.averageMark = average;
        this.result = result;
        this.rank = rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public Result getResult() {
        return result;
    }

    public int getTotalMark() {
        return totalMark;
    }
    
    public int getRank() {
        return rank;
    }

    public int getAverageMark() {
        return averageMark;
    }
    
}
