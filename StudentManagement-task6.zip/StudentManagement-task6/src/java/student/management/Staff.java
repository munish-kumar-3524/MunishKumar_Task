/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package student.management;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Munish kumar
 */
public class Staff{
    private String name;
    private String Id;
    private String password;
    private Set<String> handlingSubjects; 
    
    public Staff(String name, String Id, String password) {
        this.name = name;
        this.Id = Id;
        this.password = password;
        this.handlingSubjects = new HashSet<>();
    }

    public Staff(String name, String Id) {
        this.name = name;
        this.Id = Id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<String> getHandlingSubjects() {
        return handlingSubjects;
    }

    public void setHandlingSubjects(Set<String> handlingSubjects) {
        this.handlingSubjects = handlingSubjects;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }
}
