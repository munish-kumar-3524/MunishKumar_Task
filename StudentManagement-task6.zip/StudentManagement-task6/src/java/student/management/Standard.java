/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package student.management;
import dao.student.manager.ClassRoomDao;
import dao.student.manager.StaffDao;
import dao.student.manager.StandardDao;
import dao.student.manager.StandardDaoInterface;
import dao.student.manager.StudentDao;
import dao.student.manager.StudentDaoInterface;
import dao.student.manager.SubjectDao;
import java.util.HashSet;
import java.util.Set;
import dao.student.manager.ClassRoomDaoInterface;
import dao.student.manager.StaffDaoInterface;
import dao.student.manager.SubjectDaoInterface;

/**
 *
 * @author Munish kumar
 */
public class Standard {
    private String name;
    private String id;
    private Set<String> classRooms;
    private Set<String> staffs;
    private Set<String> subjects;
    private static StudentDaoInterface studentDao = new StudentDao();
    private static StandardDaoInterface standardDao = new StandardDao();
    private static ClassRoomDaoInterface classroomDao = new ClassRoomDao();
    private static StaffDaoInterface staffDao = new StaffDao();
    private static SubjectDaoInterface subjectDao = new SubjectDao();

    public Standard(String name, String id) {
        this.name = name;
        this.id = id;
        this.classRooms = new HashSet<>();
        this.staffs = new HashSet<>();
        this.subjects = new HashSet<>();
    }

    public Standard(){
        this.classRooms = new HashSet<>();
        this.staffs = new HashSet<>();
        this.subjects = new HashSet<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setClassRooms(Set<String> classRooms) {
        this.classRooms = classRooms;
    }

    public void setStaffs(Set<String> staffs) {
        this.staffs = staffs;
    }

    public void setSubjects(Set<String> subjects) {
        this.subjects = subjects;
    }
    
    public Set<String> getSubjects() {
        return subjects;
    }
    
    public Set<String> getClassRoom() {
        return classRooms;
    }

    public Set<String> getStaffs() {
        return staffs;
    }
    
    public int getTotalNumberOfClassRoom() {
        return classRooms.size();
    }

    public int getTotalNumberOfStaff() {
        return staffs.size();
    }
    
    public static void setStudentsReportCardDetails(Student student){
        int totalMark = 0;
        int averageMark;
        String result = "PASS";
        for(String subject : student.getSubjectsAndMarks().keySet()){
            int mark = student.getSubjectsAndMarks().get(subject);
            totalMark += mark;
            if(mark < 50){
                result = "FAIL";
            }
        }
        averageMark = totalMark/student.getSubjectsAndMarks().size();
        studentDao.insertStudentReportCard(student.getId(), totalMark, averageMark, result);
    }
    
    public static void setStudentToClass(Student student, String standardName) {
        String standardId = standardDao.getStandardIdByStandardName(standardName);
        Set<String> setOfClass = standardDao.getSetOfClassroomInOneStandard(standardId);
        String classroomId = null;
        int count = Integer.MAX_VALUE;
        for(String classroom : setOfClass){
            int numberOfStudents = classroomDao.countOfStudentInTheClassroom(classroom);
            if(count > numberOfStudents){
                classroomId = classroom;
                count = numberOfStudents;
            }
        }
        classroomDao.insertClassRoomAndStudent(classroomId, student.getId());
    }
    
    public static void setStaffToClass(Staff staff){
        Set<String> setOfClassRoom = classroomDao.getAllClassRoomId();
        for(String tempClassRoom : setOfClassRoom){
            for(String subject : staff.getHandlingSubjects()){
                String subjectId = subjectDao.getSubjectIdBySubjectName(subject);
                int StaffHandlingId = staffDao.getStaffHandlingOfASpecificClass(subjectId, tempClassRoom);
                String staffId = staffDao.getStaffIdByStaffHandlingId(StaffHandlingId);
                int tempStaffHandlingId = staffDao.getStaffHandlinfIdByStaffIdAndSubjectId(staff.getId(), subjectId);
                if(StaffHandlingId != -1){
                    if(staffDao.getTotalNumberOfClassAllocatedToASimgleStaff(staffId) < staffDao.getTotalNumberOfClassAllocatedToASimgleStaff(staff.getId())){
                        classroomDao.removeRowFromClassroomStaffWithSubject(tempClassRoom, StaffHandlingId);
                        classroomDao.insertClassRoomStaffWithSubject(tempClassRoom, tempStaffHandlingId);
                    }
                }else{
                    classroomDao.insertClassRoomStaffWithSubject(tempClassRoom, tempStaffHandlingId);
                }
            }    
        }
    }
}
