/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package student.management;

import java.util.HashMap;

/**
 *
 * @author Munish kumar
 */
public class Student {
    private String name;
    private String Id;
    private String password;
    private HashMap<String, Integer> subjectsAndMarks;
    private ReportCard reportCard;

    public Student(String name, String Id, String password) {
        this.name = name;
        this.Id = Id;
        this.password = password;
        this.subjectsAndMarks = new HashMap<>();
        this.reportCard = null;
    }

    public Student(String name, String Id) {
        this.name = name;
        this.Id = Id;
        this.subjectsAndMarks = new HashMap<>();
        this.reportCard = null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public HashMap<String, Integer> getSubjectsAndMarks() {
        return (HashMap<String, Integer>) subjectsAndMarks.clone();
    }

    public ReportCard getReportCard() {
        return reportCard;
    }

    public void setSubjectsAndMarks(HashMap<String, Integer> subjectsAndMarks) {
        this.subjectsAndMarks = subjectsAndMarks;
    }

    public void setReportCard(ReportCard reportCard) {
        this.reportCard = reportCard;
    }

}
