///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package student.management;
//
//import dao.student.manager.ClassRoomDao;
//import dao.student.manager.StaffDao;
//import dao.student.manager.StudentDao;
//import random.generator.RandomGenerator;
//import dao.student.manager.SubjectDao;
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.sql.SQLException;
//import java.util.List;
//import java.util.Scanner;
//import java.util.Set;
//import java.util.TreeMap;
//
///**
// *
// * @author Munish kumar
// */
//public class StudentManagerTester {
//    //private static Department DEPARTMENT = new Department();
//    static private final InputStreamReader ISR = new InputStreamReader(System.in);
//    static private final BufferedReader BR = new BufferedReader(ISR);
//    static private final Scanner SC = new Scanner(System.in);
//    private static final SubjectDao SUBJECT_DAO = new SubjectDao();
//    private static final ClassRoomDao CLASSROOM_DAO = new ClassRoomDao();
//    private static final StaffDao STAFF_DAO = new StaffDao();
//    private static final StudentDao STUDENT_DAO = new StudentDao();
//    private static final int NUMBER_OF_CLASSROOM = 3;
//    private static final int NUMBER_OF_SUBJECTS = 5;
//    
//    public static void main(String[] args) throws IOException, SQLException {
////        SubjectNames subjectNames[] = SubjectNames.values();
////        for(int i = 0; i < NUMBER_OF_SUBJECTS; i++){
////            SubjectNames name = subjectNames[i];
////            String id = RandomGenerator.generateId();
////            Subject subject = new Subject(name, id);
////            SubjectDao.insertSubject(subject);
////        }
////        for(int i = 0; i < NUMBER_OF_CLASSROOM; i++){
////            String id = RandomGenerator.generateId();
////            String name = RandomGenerator.generateClassName();
////            ClassRoom classRoom = new ClassRoom(id, name);
////            ClassRoomDao.insertClassRoom(classRoom);
////        }
////
////        var sub = SubjectDao.getAllSubjectNames();
////        for(int i = 0; i < NUMBER_OF_SUBJECTS; i++){
////            String name = RandomGenerator.generateName();
////            String id = RandomGenerator.generateId();
////            Staff staff = new Staff(name, id);
////            StaffDao.insertStaff(staff);
////            String subjectId = SubjectDao.getSubjectIdBySubjectName(sub.get(i));//there can be morethan one subject
////            StaffDao.insertStaffHandlingSubject(id, subjectId);
////            int staffHandlingId = StaffDao.getStaffHandlinfIdByStaffIdAndSubjectId(id, subjectId);//there can be more than one id
////            Subject subject = SubjectDao.getSubjectBySubjectId(subjectId);
////            var setOfClass = ClassRoomDao.getAllClassRoomWithStaffs();
////            Department.setStaffToClass(staff, subject, setOfClass, staffHandlingId);
////        }
////        getStudentsDetails(NUMBER_OF_CLASSROOM*10);
//        //System.exit(0);
//        
//        
//        boolean flag = true;
//        while(flag){
//            System.out.println("""
//                               1.Add Staff
//                               2.Add Student
//                               3.Display all students in rankwise
//                               4.Average mark of each subject
//                               5.Display students classwise
//                               6.List of students greaterthan or equal to average mark of a subject
//                               7.Top scorers of a subject
//                               8.Over all pass percentage
//                               9.Class wise pass percentage
//                               10.Display staff details
//                               11.Student acadamic details subject wise
//                               12.Count of students greaterthan or equalto averagemark for each subject
//                               13.update student mark
//                               14.Top mark of a student
//                               15.End""");
//            System.out.print("Enter your choice : ");
//            int choice = SC.nextInt();
//            switch(choice){
//                case 1:
//                    setStaffDetail();
//                    break;
//                case 2:
//                    setStudentDetail();
//                    break;
//                case 3:
//                    var studentList = MarkRegister.getAllStudentRankWise();
//                    displayAllStudentRankWise(studentList);
//                    break;
//                case 4:
//                    //DEPARTMENT = getDepartment();
//                    var averageMarkOfEachSubject = MarkRegister.getOverAllAverageMarkOfEachSubject();
//                    Set<String> setOfSubjectIds = averageMarkOfEachSubject.keySet();
//                    System.out.println("Subject_name \t Average_mark");
//                    for(String subjectName : setOfSubjectIds){
//                        System.out.println(SUBJECT_DAO.getSubjectNameBySubjectId(subjectName) + "\t\t" + averageMarkOfEachSubject.get(subjectName));
//                    }
//                    break; 
//                case 5:
//                    //DEPARTMENT = getDepartment();
//                    var classesWithStudent = MarkRegister.getStudentsClassWise();
//                    displayClassesWithStudent(classesWithStudent);
//                    break;
//                case 6:
//                    //DEPARTMENT = getDepartment();
//                    System.out.print("Enter the subject name : ");
//                    String subjectName = BR.readLine();
//                    var listOfStudentNames = MarkRegister.getListOfStudentsGreaterthanOrEqualtoAverageMark(subjectName);
//                    if(listOfStudentNames == null){
//                        System.out.println("No subject named " + subjectName);
//                        break;
//                    }
//                    for(String studentNames : listOfStudentNames){
//                        System.out.println(studentNames);
//                    }
//                    break;
//                case 7:
//                    //DEPARTMENT = getDepartment();
//                    var topScorerOfEachSubject = MarkRegister.getTopScorerOfEachSubject();
//                    Set<String> setOfSubjectName = topScorerOfEachSubject.keySet();
//                    for(String subject : setOfSubjectName){
//                        System.out.println("\t\t" + subject);
//                        List<String> listOfStudentName= topScorerOfEachSubject.get(subject);
//                        for(String studentName : listOfStudentName){
//                            System.out.println(studentName);
//                        }
//                    }
//                    break;
//                case 8:
//                    System.out.print("OverAll pass percentage : ");
//                    System.out.println(MarkRegister.getOverallPassPercentage()+ "%");
//                    break;
//                case 9:
//                    //DEPARTMENT = getDepartment();
//                    var classesAndPassPercentage = MarkRegister.getPassPercentageForEachClass();
//                    Set<String> setOfClassNames = classesAndPassPercentage.keySet();
//                    for(String className : setOfClassNames){
//                        System.out.print(className + " - ");
//                        System.out.println(classesAndPassPercentage.get(className));
//                    }
//                    break;
//                case 10:
//                    //DEPARTMENT = getDepartment();
//                    Set<Staff> setOfStaff = STAFF_DAO.getAllStaff();
//                    for(Staff staff : setOfStaff){
//                        System.out.println("Name : " + staff.getName());
//                        System.out.println("Id : " + staff.getId());
//                        System.out.print("Handling subjects : ");
//                        Set<String> setOfSubject = staff.getSubjects();
//                        for(String subject : setOfSubject){
//                            System.out.print(SUBJECT_DAO.getSubjectNameBySubjectId(subject) + " ");
//                        }
//                        System.out.println("\n");
//                    }
//                    break;
//                case 11:
//                    //DEPARTMENT = getDepartment();
//                    System.out.print("Enter the subject name : ");
//                    subjectName = BR.readLine();
//                    var namesAndMarks = MarkRegister.getStudentAcadamicDetailsSubjectWise(subjectName);
//                    if(namesAndMarks == null){
//                        System.out.println("No subject named " + subjectName);
//                        break;
//                    }
//                    Set<String> names = namesAndMarks.keySet();
//                    for(String name : names){
//                        System.out.print(name + " : ");
//                        System.out.println(namesAndMarks.get(name));
//                    }
//                    break;
//                case 12:
//                    var subjectAndCount = MarkRegister.getCountOfStudentsGreaterthanOrEqualtoAverageMarkForEachSubjects();
//                    Set<String> setOfNames = subjectAndCount.keySet();
//                    for(String name : setOfNames){
//                        System.out.print(name + " : ");
//                        System.out.println(subjectAndCount.get(name));
//                    }
//                    break;
//                case 13:
//                    System.out.print("Enter student name : ");
//                    String studentName = BR.readLine();
//                    String studentId = STUDENT_DAO.getStudentIdByStudentName(studentName);
//                    System.out.print("Enter subject name : ");
//                    subjectName = BR.readLine();
//                    String subjectId = SUBJECT_DAO.getSubjectIdBySubjectName(subjectName);
//                    System.out.println("Enter subject mark : ");
//                    int mark = SC.nextInt();
//                    STUDENT_DAO.updateStudentMark(studentId, subjectId, mark);
//                    Department.updateStudentsReportCardDetails(studentId);
//                    break;
//                case 14:
//                    System.out.print("Enter student name : ");
//                    studentName = BR.readLine();
//                    studentId = STUDENT_DAO.getStudentIdByStudentName(studentName);
//                    int topMark = STUDENT_DAO.getTopMarkOfAStudent(studentId);
//                    System.out.println(topMark);
//                case 15:
//                    flag = false;
//                    break;
//            }
//        }
//    }
//
//    private static void setStudentsDetails(int numberOfStudents) throws SQLException, IOException {
//        for(int i = 0; i < numberOfStudents; i++){
//            String name = RandomGenerator.generateName();
//            String id = RandomGenerator.generateId();
//            Student student = new Student(name, id);
//            STUDENT_DAO.insertStudent(student);
//            List<String> setOfSubject = SUBJECT_DAO.getAllSubjectNames();
//            for(String subjectName : setOfSubject){
//                int mark = RandomGenerator.generateMark();
//                String subjectId = SUBJECT_DAO.getSubjectIdBySubjectName(subjectName);
//                STUDENT_DAO.insertStudentAndTheirSubject(id, subjectId, mark);
//            }
//            var setOfClassRoomId = CLASSROOM_DAO.getAllClassRoomId();
//            Department.setStudentToClass(student, setOfClassRoomId);
//            Department.setStudentsReportCardDetails(student);
//        }
//    }
//
//    private static void displayAllStudentRankWise(List<Student> listOfStudents) throws SQLException, IOException {
//        if(listOfStudents.isEmpty()) return;
//        Set<String> setOfSubjectIds = listOfStudents.get(0).getSubjectsAndMarks().keySet();
//        System.out.print("Name\tId\t");
//        for(String string : setOfSubjectIds){
//            System.out.print(SUBJECT_DAO.getSubjectNameBySubjectId(string)+ "\t");
//        }
//        System.out.println("Total mark\tRank\tAverage\tResult");
//        for(Student student : listOfStudents){
//            System.out.print(student.getName() + ""
//                    + ""
//                    + "\t" + student.getId() + "\t");
//            for(String subject : setOfSubjectIds){
//                System.out.print(student.getSubjectsAndMarks().get(subject) + "\t");
//            }
//            System.out.print(student.getReportCard().getTotalMark() + "\t");
//            if(student.getReportCard().getRank() == Integer.MAX_VALUE){
//                System.out.print("-" + "\t");
//            }else{
//                System.out.print(student.getReportCard().getRank() + "\t");
//            }
//            System.out.println(student.getReportCard().getPercentage() + "\t" + student.getReportCard().getResult());
//        }
//    }
//
//    private static void setStaffDetail() throws IOException, SQLException {
//        
//        System.out.print("Enter staff name : ");
//        String name = BR.readLine();
//        String id = RandomGenerator.generateId();
//        Staff staff = new Staff(name, id);
//        STAFF_DAO.insertStaff(staff);
//
//        int numberOfHandlingSubjects;
//        System.out.print("Enter the number of subjects this staff can handle : ");
//        numberOfHandlingSubjects = SC.nextInt();
//        for(int i = 0; i < numberOfHandlingSubjects; i++){
//            System.out.print("Enter the subject name : ");
//            String subjectName = BR.readLine();
//            String subjectId = SUBJECT_DAO.getSubjectIdBySubjectName(subjectName);
//            STAFF_DAO.insertStaffHandlingSubject(id, subjectId);
//            var setOfClass = CLASSROOM_DAO.getAllClassRoomId();
//            Department.setStaffToClass(id, subjectId, setOfClass);
//        }
//    }
//
//    private static void setStudentDetail() throws IOException, SQLException {
//        System.out.print("Enter staff name : ");
//        String name = BR.readLine();
//        String id = RandomGenerator.generateId();
//        Student student = new Student(name, id);
//        STUDENT_DAO.insertStudent(student);
//        List<String> setOfSubject = SUBJECT_DAO.getAllSubjectNames();
//        for(String subjectName : setOfSubject){
//            System.out.print("Enter mark for " + subjectName + " : ");
//            int mark = SC.nextInt();
//            String subjectId = SUBJECT_DAO.getSubjectIdBySubjectName(subjectName);
//            STUDENT_DAO.insertStudentAndTheirSubject(id, subjectId, mark);
//        }
//        var setOfClassRoomId = CLASSROOM_DAO.getAllClassRoomId();
//        Department.setStudentToClass(student, setOfClassRoomId);
//        Department.setStudentsReportCardDetails(student);
//    }
//
//    private static void displayClassesWithStudent(TreeMap<String, List<Student>> classesWithStudent) throws SQLException, IOException {
//        Set<String> setOfClasses = classesWithStudent.keySet();
//        for(String classId : setOfClasses){
//            System.out.println("\t\t\tClass name : " + CLASSROOM_DAO.getClassRoomNameByClassRoomId(classId));
//            List<Student> listOfStudents = classesWithStudent.get(classId);
//            Set<String> setOfSubjectIds = listOfStudents.get(0).getSubjectsAndMarks().keySet();
//            System.out.print("Name\tId\t");
//            for(String string : setOfSubjectIds){
//                System.out.print(SUBJECT_DAO.getSubjectNameBySubjectId(string)+ "\t");
//            }
//            System.out.println("Total mark\tRank\tAverage\tResult");
//            for(Student student : listOfStudents){
//                System.out.print(student.getName() + ""
//                        + ""
//                        + "\t" + student.getId() + "\t");
//                for(String subject : setOfSubjectIds){
//                    System.out.print(student.getSubjectsAndMarks().get(subject) + "\t");
//                }
//                System.out.print(student.getReportCard().getTotalMark() + "\t");
//                if(student.getReportCard().getRank() == Integer.MAX_VALUE){
//                    System.out.print("-" + "\t");
//                }else{
//                    System.out.print(student.getReportCard().getRank() + "\t");
//                }
//                System.out.println(student.getReportCard().getPercentage() + "\t" + student.getReportCard().getResult());
//            }
//        }
//    }
//
////    private static Department getDepartment() throws SQLException, IOException {
////        DEPARTMENT.setClassRooms(ClassRoomDao.getAllClassRoomId());
////        DEPARTMENT.setStaffs(StaffDao.getAllStaffIds());
////        DEPARTMENT.setSubjects(SubjectDao.getAllSubjectIds());
////        return DEPARTMENT;
////    }
//}
