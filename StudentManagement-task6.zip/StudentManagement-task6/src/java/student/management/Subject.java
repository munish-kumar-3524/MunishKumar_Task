/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package student.management;

/**
 *
 * @author Munish kumar
 */
public class Subject {
    private SubjectNames name;
    private String Id;
    
    public Subject(SubjectNames name, String Id) {
        this.name = name;
        this.Id = Id;
    }

    public String getId() {
        return Id;
    }

    public SubjectNames getName() {
        return name;
    }
}
